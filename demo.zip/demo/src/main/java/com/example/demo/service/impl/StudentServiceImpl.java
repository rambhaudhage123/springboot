package com.example.demo.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepository;
import com.example.demo.service.StudentService;
@Service
public class StudentServiceImpl implements StudentService{
	
	private StudentRepository studentRepository;
	
	public StudentServiceImpl(StudentRepository studentRepository) {
		super();
		this.studentRepository = studentRepository;
	}
	
	@Override
	public Student saveStudent(Student student) {
		return studentRepository.save(student);
	}

	@Override
	public List<Student> getAllStudents() {
		return studentRepository.findAll();
	}
	
	public Student getStudentById(int id) {
//		Optional<Student> student = studentRepository.findById(id);
//		if (student.isPresent()) {
//			student.get();
//		}else {
//			throw new ResourceNotFoundException("Student", "Id", id);
//		}
		return studentRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Student", "Id", id));
	}

	@Override
	public Student updateStudent(Student student,int id) {
		// checking whether student with given id exist in database or not
		
		Student existingStudent = studentRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Student", "Id", id));
		existingStudent.setRollNo(student.getRollNo());
		existingStudent.setFirstName(student.getFirstName());
		existingStudent.setLastName(student.getLastName());
		existingStudent.setEmail(student.getEmail());
		existingStudent.setMobileNo(student.getMobileNo());
		// save existing employee to DB
		studentRepository.save(existingStudent);
			return existingStudent;
	}

	@Override
	public void deleteStudent(int id) {
		//check whether student exist in DB or not
		studentRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Student", "Id", id));
		studentRepository.deleteById(id);
		
	}

}
